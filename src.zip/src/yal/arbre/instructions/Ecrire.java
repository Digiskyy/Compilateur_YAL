package yal.arbre.instructions;

import yal.arbre.expressions.Expression;

public class Ecrire extends Instruction {

    protected Expression exp ;

    public Ecrire (Expression e, int n) {
        super(n) ;
        exp = e ;
    }

    @Override
    public void verifier() {
    }

    @Override
    public String toMIPS()
    {
        /*
        li $v0 , 1 	# $v0 <- 1 (code du print entier)
	    li $a0 , 2456 	# $a0 <- 2456 (valeur à afficher)
	    syscall 	# afficher
         */
        return exp.toMIPS() + "\n\tsyscall\n";

        //throw new UnsupportedOperationException("Not supported yet.");
    }

}
