package yal.arbre.expressions.operations.predicats;

import yal.arbre.expressions.Expression;
import yal.arbre.expressions.Operation;
import yal.arbre.expressions.operations.Operande;

public class PlusGrandQue extends Operation {
    public PlusGrandQue(Expression gauche, Expression droite, int n) {
        super(gauche, droite, n);
    }
}
