package yal.arbre.expressions.operations;

public abstract class Operande  {
}
